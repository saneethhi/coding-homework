var monkey,monkeyImage,bananaImage,ObstacleImage,Background,backgroundImage,score, invisibleground,bananaGroup,ObstacleGroup;

function preload(){
bananaImage = loadImage("banana.png");
ObstacleImage = loadImage("stone.png");
backgroundImage = loadImage("jungle.png");
monkeyImage = loadImage("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
}

function setup() {
  createCanvas(400, 400);
  bananaGroup = createGroup();
  ObstacleGroup = createGroup();
  Background = createSprite(0,0,400,400);
  Background.addImage("background",backgroundImage);
  monkey = createSprite(60,350,0,0);
  monkey.addImage(monkeyImage);
  monkey.scale = 0.15;
  invisibleground = createSprite(200,385,800,5);
  invisibleground.visible = false;
  invisibleground.velocityX = -6;
  score = 0;
}

function draw() {
  background(220);
  textSize = 20;
  if(keyDown("space") && monkey.y >= 330){
    monkey.velocityY = -14 ;
  }
  
  if(monkey.isTouching(bananaGroup)){
    bananaGroup.removeEach();
    score = score + 2;
  }
  
  if(monkey.isTouching(ObstacleGroup)){
   score = 0; 
   monkey.scale = 0.15;
  }  
  
  switch(score){
    case 10: player.scale = 0.12;
      break;
    case 20: player.scale = 0.14;
      break;  
    case 30: player.scale = 0.16;
      break;  
    case 40: player.scale = 0.18;
      break;      
  }    
  monkey.velocityY = monkey.velocityY + 0.8;
  
  mokey.collide(invisibleground);
  
  drawSprite();
  text("Score: ",score);
  food();
  rocks();
}

function food(){
  if(frameCount % 80 ===  0){
    var banana = createSprite(400,320,0,0);
    banana.y = random(200,320);
    banana.addImage("Banana", bananaImage);
    banana.scale = 0.05;
    banana.velocityX = -6;
    bananaGroup.add(banana);
  }
}

function rocks(){
  if(frameCount % 300 ===  0){
    var rock = createSprite(400,340,0,0);
    rock.addImage("Stone",ObstacleImage);
    rock.scale = 0.2;
    rock.velocityX = -6;
    ObstacleGroup.add(rock);
 }  
}